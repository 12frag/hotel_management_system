<?php
header('Location:http://localhost/project/index.php');
?>
	